import React, { useEffect, useState } from 'react';
import LoadProduct from '../LoadProduct/LoadProduct';

const Home = () => {

    const [events, setEvents] = useState([]);

    useEffect(() => {
        fetch('http://localhost:5000/events')
        .then(res => res.json())
        .then(data => setEvents(data))
    }, [])

    

    return (
        <div className="row">
            {
                events.map(event =><LoadProduct event={event}></LoadProduct>)
            }
        </div>
    );
};

export default Home;