import { Button } from 'bootstrap';
import React, { useEffect, useState } from 'react';
import { Card, Col, Container, Row } from 'react-bootstrap';
import './LoadProduct.css';

const LoadProduct = (props) => {
    console.log("check", props.event);
    const { name, wight, price, imageURL } = props.event;
    return (
        <div className="col-md-3" style={{ height: '408px' }}>
            <div className="singleCard py-5" style={{ textAlign: 'center', borderRadius: "15px", marginTop: '10px' }}>

                <img className="img-fluid w-50" src={imageURL} alt="" />
                <div>
                    <h5 className="mt-2"> {name} </h5>
                </div>
                <Container>
                    <Row>
                        <Col md={4}>${price}</Col>
                        <Col md={{ span: 4, offset: 4 }}>Buy Now</Col>
                    </Row>
                    </Container>    
            </div>
            </div>
    );
};

export default LoadProduct;