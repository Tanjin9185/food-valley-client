import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h1 className="noMatchText">No route match</h1>
        </div>
    );
};

export default NotFound;