const firebaseConfig = {
  apiKey: "AIzaSyBd83FMiOEInhpVXLDUVygploG8ZIhOIiE",
  authDomain: "food-valley-2dcb2.firebaseapp.com",
  projectId: "food-valley-2dcb2",
  storageBucket: "food-valley-2dcb2.appspot.com",
  messagingSenderId: "816308469016",
  appId: "1:816308469016:web:d5aa1d19664770e313f26d"
};
  export default firebaseConfig;